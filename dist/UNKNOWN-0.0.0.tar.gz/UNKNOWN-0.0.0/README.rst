==============
Micro
==============

Micro projects is a high-level frameworks developed to compile/debug STM32 projects


