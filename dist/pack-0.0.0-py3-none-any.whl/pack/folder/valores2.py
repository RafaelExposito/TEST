


VALOR2=10

def resta(num1,num2):
    return num1-num2



