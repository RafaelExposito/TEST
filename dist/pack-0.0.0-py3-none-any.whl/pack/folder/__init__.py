import pathlib
import sys

'''
sys.path.append('C:\\Users\\usuario\\Desktop\\TEST')
sys.path.append('C:\\Users\\usuario\\Desktop\\TEST\\pack')



from pack.conf.file_managment import *

project_folder=get_project_path(__file__,'pack')
add_path(project_folder)
sys.path.append('C:\\Users\\usuario\\Desktop\\TEST')
sys.path.append('C:\\Users\\usuario\\Desktop\\TEST\\pack')

'''



#from pack.folder import valores2


from pack.folder import valores2

__all__ = ["valores2"]
