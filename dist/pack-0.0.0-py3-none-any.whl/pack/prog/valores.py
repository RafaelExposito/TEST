'''
import sys



sys.path.append('C:\\Users\\usuario\\Desktop\\TEST')
sys.path.append('C:\\Users\\usuario\\Desktop\\TEST\\pack')

'''


VALOR=10


def hola():
    print('HELLO')
    print(10)


